/**
 *    author:  Taara Sinh Aatrey
 *    created: 20.10.2022 20:33:19
**/

#include "bits/stdc++.h"

using namespace std;

#ifdef AATREY_DEBUG
#include "debug.hpp"
#else
#define dbg(...)
#endif

#define int int64_t

signed main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int n, m;
    cin >> n >> m;
    const int inf = 1e18L + 5;
    int mx = -inf;
    bool ok = true;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        if (mx > x) {
            if (x + mx > m) {
                ok = false;
            }
        }
        else {
            mx = x;
        }
    }
    cout << ok << '\n';
    return 0;
}