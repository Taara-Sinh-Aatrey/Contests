/**
 *    author:  Taara Sinh Aatrey
 *    created: 21.10.2022 07:34:16
**/

#include "bits/stdc++.h"

using namespace std;

#ifdef AATREY_DEBUG
#include "debug.hpp"
#else
#define dbg(...)
#endif

#define int int64_t

signed main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int n;
    cin >> n;
    vector<int> a(n);
    for (int i = 0; i < n; i++) {
        cin >> a[i], --a[i];
    }
    vector<int> ans(n);
    for (int i = 0; i < n; i++) {
        if (ans[i])
            continue;
        int j = i, cnt = 0;
        do {
            cnt++;
            j = a[j];
        } while (j != i);
        j = i;
        do {
            ans[j] = cnt;
            j = a[j];
        } while (j != i);
    }
    for (auto &x : ans) {
        cout << x << " ";
    }
    return 0;
}