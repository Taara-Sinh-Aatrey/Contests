/**
 *    author:  Taara Sinh Aatrey
 *    created: 21.10.2022 08:03:57
**/

#include "bits/stdc++.h"

using namespace std;

#ifdef AATREY_DEBUG
#include "debug.hpp"
#else
#define dbg(...)
#endif

#define int int64_t

signed main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int m, n;
    cin >> m >> n;
    m *= 2;
    const int inf = 1e18L + 5;
    vector<int> dp(m + 1, -inf);
    dp[0] = 0;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        for (int j = min(m - 1, 2 * i); j >= 0; j--) {
            dp[j + 1] = max(dp[j + 1], dp[j] + ((j + 1) & 1 ? -x : x));
        }
    }
    cout << *max_element(dp.begin(), dp.end());
    return 0;
}