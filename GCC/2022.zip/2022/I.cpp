/**
 *    author:  Taara Sinh Aatrey
 *    created: 21.10.2022 08:30:28
**/

#include "bits/stdc++.h"

using namespace std;

#ifdef AATREY_DEBUG
#include "debug.hpp"
#else
#define dbg(...)
#endif

#define int int64_t

signed main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int n;
    cin >> n;
    vector<vector<int>> pref(n + 1, vector<int>(n + 1));
    for (int i = 1; i <= n; i++) {
        string s;
        cin >> s;
        for (int j = 1; j <= n; j++) {
            pref[i][j] = (s[j - 1] == '$') + pref[i][j - 1] + pref[i - 1][j] - pref[i - 1][j - 1];
        }
    }
    int dp[n + 1][n + 1][n + 1][n + 1];
    const int inf = 1e18L + 5;
    for (int a = n; a >= 1; a--) {
        for (int b = n; b >= 1; b--) {
            for (int c = a; c <= n; c++) {
                for (int d = b; d <= n; d++) {
                    dp[a][b][c][d] = inf;
                    /*
                    a,b           | a,y+1
                                  |
                                  |
                                  |
                    ____________x,y              x,d
                    x+1,b
                                
                                  
                                  
                                c,y              c,d
                    */
                    int L = min(c - a, d - b);
                    for (int l = 0; l <= L; l++) {
                        int x = a + l, y = b + l;
                        int sum = pref[x][y] - pref[a - 1][y] - pref[x][b - 1] + pref[a - 1][b - 1];
                        int adjacent = min(
                            (y + 1 <= d ? dp[a][y + 1][c][d] : 0) + 
                            (x + 1 <= c ? dp[x + 1][b][c][y] : 0), 
                            (y + 1 <= d ? dp[a][y + 1][x][d] : 0) + 
                            (x + 1 <= c ? dp[x + 1][b][c][d] : 0)
                        );
                        dp[a][b][c][d] = min(dp[a][b][c][d], adjacent + min(dp[a][b][x][y], (sum > 0 ? l + 1 : 0)));
                    }
                }
            }
        }
    }
    cout << dp[1][1][n][n] << '\n';
    return 0;
}